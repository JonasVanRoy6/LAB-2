import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SignupScreen = () => {
  return (
    <View>
      <Text>SignupScreen</Text>
    </View>
  )
}

export default SignupScreen

const styles = StyleSheet.create({})