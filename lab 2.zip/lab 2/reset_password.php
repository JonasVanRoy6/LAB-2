<?php
// reset_password.php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reset_token = $_POST['reset_token'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password === $confirm_password) {
        $sql = "SELECT user_id FROM password_resets WHERE reset_token = :reset_token AND expires_at > NOW()";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['reset_token' => $reset_token]);
        $reset_request = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($reset_request) {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            $sql = "UPDATE users SET password = :password WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['password' => $hashed_password, 'id' => $reset_request['user_id']]);

            // Delete the password reset request
            $sql = "DELETE FROM password_resets WHERE reset_token = :reset_token";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['reset_token' => $reset_token]);

            // Redirect to login page after successful password reset
            header("Location: login.html");
            exit();
        } else {
            echo "Invalid or expired reset token.";
        }
    } else {
        echo "Passwords do not match!";
    }
}
?>