document.getElementById('delete-account-btn').addEventListener('click', function() {
    document.getElementById('overlay').style.display = 'flex';
});

document.getElementById('cancel-btn').addEventListener('click', function() {
    document.getElementById('overlay').style.display = 'none';
});
