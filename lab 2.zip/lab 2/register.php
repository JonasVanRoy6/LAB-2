<?php
// register.php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO users (firstname, lastname, email, password) VALUES (:firstname, :lastname, :email, :password)";
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute(['firstname' => $firstname, 'lastname' => $lastname, 'email' => $email, 'password' => $password]);
        header("Location: login.html");
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            echo "Email already registered!";
        } else {
            echo "Error: " . $e->getMessage();
        }
    }
}
?>
