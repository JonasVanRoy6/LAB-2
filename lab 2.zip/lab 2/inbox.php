<?php
session_start();
require 'config.php'; // Include the PDO connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}

try {
    // Retrieve the logged-in user's ID from the session
    $userId = $_SESSION['user_id'];

    // Prepare the SQL statement to fetch the first name
    $stmt = $pdo->prepare("SELECT firstname FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $firstName = $user['firstname'];

    // Prepare the SQL statement to fetch the license plate
    $stmt = $pdo->prepare("SELECT license_plate FROM vehicles WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 1");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    $vehicle = $stmt->fetch(PDO::FETCH_ASSOC);
    $licensePlate = $vehicle['license_plate'];

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>





<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="inbox.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="container">
        <section class="sidebar">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
            </div>
            <ul class="nav">
                <li class="nav-item">
                    <i class='bx bxs-home' ></i>
                    <a href="home.html"><span>Home</span></a>
                </li>
                <li class="nav-item active">
                    <i class='bx bxs-inbox'></i>
                    <a href="inbox.html"><span>Inbox</span></a>
                </li>
                <li class="nav-item">
                    <i class='bx bxs-car'></i>
                    <a href="voertuigen.html"><span>Voertuigen</span></a>
                </li>
                <li class="nav-item">
                    <i class='bx bxs-calendar'></i>
                    <a href="kalender.html"><span>Kalender</span></a>
                </li>
            </ul>
            <div class="separator"></div>
            <ul class="nav general">
                <span id="algemeen">Algemeen</span>
                <li class="nav-item">
                    <i class='bx bx-cog' ></i>
                    <a href="instellingen.html"><span>Instellingen</span></a>
                </li>
                <li class="nav-item">
                    <i class='bx bxs-help-circle' ></i>
                    <a href="help.html"><span>Help</span></a>
                </li>
                <div class="nav-item logout">
                    <i class='bx bx-log-out' ></i>
                    <a href="logout.html"><span>Logout</span></a>
                </div>
            </ul>
        </section>
        <main class="main-content">
            <section class="inbox">
                <header>
                    <h1>Inbox</h1>
                    <div class="search-bar">
                        <input type="text" placeholder="Zoeken">
                    </div>
                    <div class="filters">
                        <a href="inbox.html">
                        <button class="filter active">Alles</button></a>
                        <a href="gelezen.html">
                        <button class="filter">Gelezen</button></a>
                        <a href="nietgelezen.html">
                        <button class="filter">Niet Gelezen</button></a>
                    </div>
                </header>
                <ul class="messages">
                    <li class="messageg">
                        <h2>Belastingaangifte 2024</h2>
                        <p>Beste <?php echo htmlspecialchars($firstName); ?>, We willen u informeren dat de belastingaangifte voor 2024 nu beschikbaar is...</p>
                        <a href="#">Gisteren</a>
                    </li>
                    <li class="message">
                        <h2>Verkeersboete</h2>
                        <p>Beste <?php echo htmlspecialchars($firstName); ?>, U hebt een snelheidsboete met nummerplaat <?php echo htmlspecialchars($licensePlate); ?>...</p>
                        <a href="#">Gisteren</a>
                    </li>
                    <li class="messageg">
                        <h2>Belastingaangifte 2024</h2>
                        <p>Beste <?php echo htmlspecialchars($firstName); ?>, We willen u informeren dat de belastingaangifte voor 2024 nu beschikbaar is...</p>
                        <a href="#">Gisteren</a>
                    </li>
                    <li class="message">
                        <h2>Belastingaangifte 2024</h2>
                        <p>Beste <?php echo htmlspecialchars($firstName); ?>, We willen u informeren dat de belastingaangifte voor 2024 nu beschikbaar is...</p>
                        <a href="#">Gisteren</a>
                    </li>
                    <!-- Herhaal bovenstaande <li> voor meerdere berichten -->
                </ul>
            </section>
            <section class="message-detail">
            <div class="actions">
                    
                        <a href=""><i class="fas fa-solid fa-envelope"></i>Markeren als ongelezen</a>
                        
                        <a href=""><i class="fas fa-regular fa-star"></i>Belangrijk</a>
                        
                        <a href=""><i class="fas fa-solid fa-trash"></i>Verwijderen</a>
                        
                        <a href=""><i class="fas fa-solid fa-print"></i>Afdrukken</a>
                    </div>
                <article>
                    <div id="belasting">
                    <h2>Belastingaangifte 2024</h2>
                    </div>
                    <p>Beste <?php echo htmlspecialchars($firstName); ?>,</p>
                    <p>We willen u informeren dat de belastingaangifte van 2024 voor uw auto met nummerplaat <?php echo htmlspecialchars($licensePlate); ?>  nu beschikbaar is. Het is belangrijk om op tijd te beginnen met het verzamelen van alle benodigde informatie met betrekking tot uw voertuig.</p>
                    <p>Hier zijn enkele stappen die u kunt volgen om uw aangifte soepel te laten verlopen:</p>
                    <ol>
                        <li>Verzamel Documenten...</li>
                        <li>Controleer Aftrekposten...</li>
                        <li>Gebruik de Online Portaal...</li>
                        <li>Belastingadviseur...</li>
                        <li>Deadline...</li>
                    </ol>
                    <p>Als u vragen heeft of hulp nodig heeft...</p>
                    <p>Met vriendelijke groet, [Uw Naam of Bedrijfsnaam]</p>
                    <p>[Contactinformatie]</p>
                </article>
                <div class="attachments">
                    <span>Bijlagen:</span>
                    <div class="attachment">
                        <i class="icon document"></i>
                        Document
                    </div>
                    <div class="attachment">
                        <i class="icon document"></i>
                        Document
                    </div>
                </div>
            </section>
        </main>
    </div>
</body>
</html>