<?php
session_start();
require 'config.php'; // Include the PDO connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}

try {
    // Retrieve the logged-in user's ID from the session
    $userId = $_SESSION['user_id'];

    $stmt = $pdo->prepare("SELECT firstname FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $firstName = $user['firstname'];

    // Prepare the SQL statement to fetch all license plates
    $stmt = $pdo->prepare("SELECT license_plate FROM vehicles WHERE user_id = :user_id ORDER BY created_at DESC");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $hasVehicles = !empty($vehicles);

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>



<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="home.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body>
    <div class="desktop"> 
    <section class="sidebar">
        <div class="logo">
            <img src="images/logo.png" alt="logo">
        </div>
        <ul class="nav">
            <li class="nav-item active">
                <i class='bx bxs-home' ></i>
                <a href="home.php"><span>Home</span></a>
            </li>
            <li class="nav-item">
                <i class='bx bxs-inbox'></i>
                <a href="inbox.php"><span>Inbox</span></a>
            </li>
           
            <li class="nav-item">
                <i class='bx bxs-calendar'></i>
                <a href="kalender.html"><span>Kalender</span></a>
            </li>
        </ul>
        <div class="separator"></div>
        <ul class="nav general">
            <span id="algemeen">Algemeen</span>
            <li class="nav-item">
                <i class='bx bx-cog' ></i>
                <a href="instellingen.html"><span>Instellingen</span></a>
            </li>
            <li class="nav-item">
                <i class='bx bxs-help-circle' ></i>
                <a href="help.html"><span>Help</span></a>
            </li>
            <div class="nav-item logout">
                <i class='bx bx-log-out' ></i>
                <a href="logout.html"><span>Logout</span></a>
            </div>
        </ul>
    </section>

    
    <div class="main-content <?php echo $hasVehicles ? 'active' : ''; ?>">
    <header>
        <h1>Welkom Terug, <?php echo htmlspecialchars($firstName); ?></h1>
        <div class="user-right">
            <i class='bx bx-plus' onclick="showOverlay()"></i>
            <div class="car-picker"> 
                <label for="cars">Kies een kenteken:</label>
                <select id="cars" name="cars">
                    <?php foreach ($vehicles as $vehicle): ?>
                        <option value="<?php echo htmlspecialchars($vehicle['license_plate']); ?>">
                            <?php echo htmlspecialchars($vehicle['license_plate']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </header>

        <div class="main-container">

        <div class="main-left">
            <section class="messages">
                <div class="messages-container">
                    <div class="messages-title">
                        <h2>Recente Berichten</h2>
                        <a href="inbox.php">Alles bekijken</a>
                    </div>
                    <div class="messages-row">
                        <span class="title">Verkeersbelasting 2024</span>
                        <span class="date">Gisteren</span>
                        <a href="inbox.php"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="messages-row">
                        <span class="title">Verkeersbelasting 2024</span>
                        <span class="date">Gisteren</span>
                        <a href="inbox.php"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="messages-row">
                        <span class="title">Verkeersbelasting 2024</span>
                        <span class="date">Gisteren</span>
                        <a href="inbox.php"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="messages-row">
                        <span class="title">Verkeersbelasting 2024</span>
                        <span class="date">Gisteren</span>
                        <a href="inbox.php"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </section>
            <section class="payments">
                <div class="payments-container">
                    <div class="payment-title">
                        <h2>Aankomende Betalingen</h2>
                        <a href="inbox.html">Alles bekijken</a>
                    </div>
                    <div class="payments-row">
                        <span class="title">Verzekeringspremie</span>
                        <span class="bedrag">€40</span>
                        <span class="date">2 mei 2024</span>
                        <a class="hovering" href="inbox.php"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="payments-row">
                        <span class="title">Wegenbelasting</span>
                        <span class="bedrag">€80</span>
                        <span class="date">Gisteren</span>
                        <a id="hovering" href="inbox.php"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="payments-row">
                        <span class="title">APK Keuring</span>
                        <span class="bedrag">€40</span>
                        <span class="date">7 mei 2024</span>
                        <a class="hovering" href="#"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </section>
        </div>
        

        <div class="main-right">
            <section class="deadlines">
                <div class="deadlines-text">
                    <h2>Deadlines</h2>
                    <input type="date" id="deadline-date" name="deadline-date" value="2024-06-20">
                </div>
                <div class="deadlines-inhoud">
    <div class="deadline-item">
        <div class="deadline-title">Keuring</div>
        <div class="deadline-content">
            <div class="deadline-line"></div>
            <div class="deadline-text">Je kan al naar de keuring vanaf 30 juni</div>
            <div class="deadline-date">30 Aug 2024</div>
        </div>
    </div>
    <div class="deadline-separator"></div>
    <div class="deadline-item">
        <div class="deadline-title">Jaarlijks onderhoud</div>
        <div class="deadline-content">
            <div class="deadline-line"></div>
            <div class="deadline-text">Breng de auto binnen voor het jaarlijkse onderhoud.</div>
            <div class="deadline-date">1 Sep 2024</div>
        </div>
    </div>
    
</div>
            </section>
            <section class="car-info">
    <div class="car-info-inhoud">
        <i class='bx bxs-car'></i>
        <i class='bx bx-info-circle'></i>
    </div>

    <div class="car-info-popup" id="carInfoPopup">
        <h3>Voertuig Informatie</h3>
        <p id="carModel">Model: Onbekend</p>
        <p id="lezInfo">Toegestaan in LEZ: Onbekend</p>
        <p id="costInfo">Gemiddelde extra kostprijs na 5 jaar: Onbekend</p>
    </div>
</section>
        </div>
        </div>
    </div>
        <div class="no-vehicles" onclick="showOverlay()<?php echo $hasVehicles ? 'hidden' : ''; ?>">
            <p>Voertuig toevoegen</p>
        <button id="add-vehicle-btn"> <span class="plus" >+</span></button>
    </div>
        <div id="overlay2" class="overlay2"></div>
        <div id="popup" class="popup">
            <p>vehicle added!</p>
        </div>
    
        <div id="overlay" class="overlay">
            <div class="container2">
                <h2>Voertuig Toevoegen</h2>
                <form id="licensePlateForm" action="save_license_plate.php" method="POST">
                    <div class="input-group">
                        <img src="images/B.png" alt="EU flag">
                        <input type="text" name="licensePlate" id="licensePlate" placeholder="Kenteken" oninput="enableAddButton()" required>
                    </div>
                    <button type="submit" id="addButton" disabled>Voeg toe</button>
                </form>
            </div>
        </div>
            </div>
        </div>
        </div> 
        
        <div class="mobile">
        <section class="heading">
        <div class="header">
                <a href="#" id="menu-button"><i class='bx bx-menu-alt-left'></i></a>
            <div class="car-picker">
                <i class='bx bx-plus' onclick="showOverlay()"></i>
                <label for="cars" class="car-label"></label>
                <select class="cars">
                <?php foreach ($vehicles as $vehicle): ?>
                        <option value="<?php echo htmlspecialchars($vehicle['license_plate']); ?>">
                            <?php echo htmlspecialchars($vehicle['license_plate']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <i class='bx bx-dots-vertical-rounded'></i>
        </div>

        <div class="mobile-nav" id="mobile-nav">
        <button id="close-nav" class="close-nav">&times;</button>

            <a href="#" class="nav-item">Calendar</a>
            <a href="#" class="nav-item">Settings</a>
            <a href="#" class="nav-item">Logout</a>
        </div>

        <div class="nav">
            <a href="#" class="nav-link active" data-target="messages">Berichten</a>
            <a href="#" class="nav-link" data-target="deadlines">Deadlines</a>
            <a href="#" class="nav-link" data-target="payments">Betalingen</a>
        </div>

        <h1 id="section-title">Recente Berichten</h1> 
    </section>
    <div class="content">
        <div id="messages" class="content-section active">
            <div class="messages-row">
                <div class="messages-content">
                    <span class="title">Verkeersbelasting 2024</span>
                    <span class="date">Gisteren</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="messages-row">
                <div class="messages-content">
                    <span class="title">Verkeersbelasting 2024</span>
                    <span class="date">Gisteren</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="messages-row">
                <div class="messages-content">
                    <span class="title">Verkeersbelasting 2024</span>
                    <span class="date">Gisteren</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="messages-row">
                <div class="messages-content">
                    <span class="title">Verkeersbelasting 2024</span>
                    <span class="date">Gisteren</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="messages-row">
                <div class="messages-content">
                    <span class="title">Nieuwe Documenten</span>
                    <span class="date">Vandaag</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="messages-row">
                <div class="messages-content">
                    <span class="title">Jaarlijkse Herinnering</span>
                    <span class="date">Afgelopen week</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="messages-row">
                <div class="messages-content">
                    <span class="title">Belastingaangifte</span>
                    <span class="date">Eerder deze maand</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="messages-row">
                <div class="messages-content">
                    <span class="title">Verkeersboete</span>
                    <span class="date">Vorige maand</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
        </div>
        <div id="deadlines" class="content-section" style="display:none;">
            <div class="deadlines-row">
                <div class="deadlines-content">
                    <span class="title">Keuring</span>
                    <span class="date">2 mei 2024</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="deadlines-row">
                <div class="deadlines-content">
                    <span class="title">Wegenbelasting</span>
                    <span class="date">Gisteren</span>
                </div>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="deadlines-row">
                <div class="deadlines-content">
                    <span class="title">APK Keuring</span>
                    <span class="date">7 mei 2024</span>
                </div>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="deadlines-row">
                <div class="deadlines-content">
                    <span class="title">Verzekeringskeuring</span>
                    <span class="date">15 mei 2024</span>
                </div>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="deadlines-row">
                <div class="deadlines-content">
                    <span class="title">Onderhoudsbeurt</span>
                    <span class="date">20 mei 2024</span>
                </div>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="deadlines-row">
                <div class="deadlines-content">
                    <span class="title">Verzamelinspectie</span>
                    <span class="date">25 juni 2024</span>
                </div>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="deadlines-row">
                <div class="deadlines-content">
                    <span class="title">Jaarlijkse Check-up</span>
                    <span class="date">10 juli 2024</span>
                </div>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="deadlines-row">
                <div class="deadlines-content">
                    <span class="title">Bandenwissel</span>
                    <span class="date">1 augustus 2024</span>
                </div>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
        </div>
        <div id="payments" class="content-section" style="display:none;">
            <div class="payments-row-mobile">
                <div class="payments-content-mobile">
                    <span class="title">Verzekeringspremie</span>
                    <span class="date">Tegen morgen</span>
                </div>
                <span class="bedrag">€40</span>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="payments-row-mobile">
                <div class="payments-content-mobile">
                    <span class="title">Wegenbelasting</span>
                    <span class="date">Tegen do, 5 september 2024</span>
                </div>
                <span class="bedrag">€80</span>
                <a href="inbox.html"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="payments-row-mobile">
                <div class="payments-content-mobile">
                    <span class="title">APK Keuring</span>
                    <span class="date">Tegen wo, 11 september 2024</span>
                </div>
                <span class="bedrag">€40</span>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="payments-row-mobile">
                <div class="payments-content-mobile">
                    <span class="title">Motorrijtuigenbelasting</span>
                    <span class="date">Tegen ma, 30 september 2024</span>
                </div>
                <span class="bedrag">€60</span>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="payments-row-mobile">
                <div class="payments-content-mobile">
                    <span class="title">Autoverzekering</span>
                    <span class="date">Tegen vr, 15 oktober 2024</span>
                </div>
                <span class="bedrag">€120</span>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="payments-row-mobile">
                <div class="payments-content-mobile">
                    <span class="title">Parkeerkosten</span>
                    <span class="date">Tegen zo, 20 oktober 2024</span>
                </div>
                <span class="bedrag">€30</span>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="payments-row-mobile">
                <div class="payments-content-mobile">
                    <span class="title">Wegenbelasting</span>
                    <span class="date">Tegen do, 5 november 2024</span>
                </div>
                <span class="bedrag">€80</span>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
            <div class="payments-row-mobile">
                <div class="payments-content-mobile">
                    <span class="title">Tuning Kosten</span>
                    <span class="date">Tegen di, 10 december 2024</span>
                </div>
                <span class="bedrag">€150</span>
                <a href="#"><i class='bx bx-right-arrow-alt'></i></a>
            </div>
        </div>
    </div>
        </div>
        <script >
        document.addEventListener('DOMContentLoaded', function() {
    const carSelect = document.getElementById('cars');

    function updateCarInfo() {
        const selectedPlate = carSelect.value;

        // Controleer het eerste karakter van de nummerplaat
        if (selectedPlate.startsWith('1')) {
            document.getElementById('carModel').textContent = "Model: BMW 116I";
            document.getElementById('lezInfo').textContent = "Toegestaan in LEZ: Ja";
            document.getElementById('costInfo').textContent = "Gemiddelde extra kostprijs na 5 jaar: €12.000";
        } else if (selectedPlate.startsWith('2')) {
            document.getElementById('carModel').textContent = "Model: MG 4";
            document.getElementById('lezInfo').textContent = "Toegestaan in LEZ: ja";
            document.getElementById('costInfo').textContent = "Gemiddelde extra kostprijs na 5 jaar: €4.132";
        } else {
            // Optioneel: Stel een standaardweergave in voor andere nummerplaten
            document.getElementById('carModel').textContent = "Model: Bmw E36 M3";
            document.getElementById('lezInfo').textContent = "Toegestaan in LEZ: Nee";
            document.getElementById('costInfo').textContent = "Gemiddelde extra kostprijs na 5 jaar: 20.000";
        }
    }

    // Voeg event listener toe aan de dropdown
    carSelect.addEventListener('change', updateCarInfo);

    // Roep de functie eenmalig aan bij pagina laden
    updateCarInfo();
});
</script>  
    <script src="home.js"></script>
    <script src="mobile.js"></script>
    
</body>
</html>
