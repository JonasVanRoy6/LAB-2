<?php
session_start();
require 'config.php'; // Include the PDO connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}

try {
    // Retrieve the logged-in user's ID from the session
    $userId = $_SESSION['user_id'];

    $stmt = $pdo->prepare("SELECT firstname FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $firstName = $user['firstname'];

    // Prepare the SQL statement to fetch all license plates
    $stmt = $pdo->prepare("SELECT license_plate FROM vehicles WHERE user_id = :user_id ORDER BY created_at DESC");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $hasVehicles = !empty($vehicles);

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>



<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="home.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body>
    <section class="sidebar">
        <div class="logo">
            <img src="images/logo.png" alt="logo">
        </div>
        <ul class="nav">
            <li class="nav-item active">
                <i class='bx bxs-home' ></i>
                <a href="home.php"><span>Home</span></a>
            </li>
            <li class="nav-item">
                <i class='bx bxs-inbox'></i>
                <a href="inbox.php"><span>Inbox</span></a>
            </li>
            <li class="nav-item">
                <i class='bx bxs-car'></i>
                <a href="voertuigen.html"><span>Voertuigen</span></a>
            </li>
            <li class="nav-item">
                <i class='bx bxs-calendar'></i>
                <a href="kalender.html"><span>Kalender</span></a>
            </li>
        </ul>
        <div class="separator"></div>
        <ul class="nav general">
            <span id="algemeen">Algemeen</span>
            <li class="nav-item">
                <i class='bx bx-cog' ></i>
                <a href="instellingen.html"><span>Instellingen</span></a>
            </li>
            <li class="nav-item">
                <i class='bx bxs-help-circle' ></i>
                <a href="help.html"><span>Help</span></a>
            </li>
            <div class="nav-item logout">
                <i class='bx bx-log-out' ></i>
                <a href="logout.html"><span>Logout</span></a>
            </div>
        </ul>
    </section>

    
    <div class="main-content <?php echo $hasVehicles ? 'active' : 'hidden'; ?>">
        <header>
            <h1>Welkom Terug, <?php echo htmlspecialchars($firstName); ?></h1>
            <div class="user-right">
                <i class='bx bx-plus' onclick="showOverlay()"></i>
                <div class="car-picker"> 
                    <label for="cars">Kies een kenteken:</label>
                    <select id="cars" name="cars">
                        <?php foreach ($vehicles as $vehicle): ?>
                            <option value="<?php echo htmlspecialchars($vehicle['license_plate']); ?>">
                                <?php echo htmlspecialchars($vehicle['license_plate']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </header>

        <div class="main-container">

        <div class="main-left">
            <section class="messages">
                <div class="messages-container">
                    <div class="messages-title">
                        <h2>Recente Berichten</h2>
                        <a href="inbox.html">Alles bekijken</a>
                    </div>
                    <div class="messages-row">
                        <span class="title">Verkeersbelasting 2024</span>
                        <span class="date">Gisteren</span>
                        <a href="inbox.html"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="messages-row">
                        <span class="title">Verkeersbelasting 2024</span>
                        <span class="date">Gisteren</span>
                        <a href="inbox.html"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="messages-row">
                        <span class="title">Verkeersbelasting 2024</span>
                        <span class="date">Gisteren</span>
                        <a href="inbox.html"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="messages-row">
                        <span class="title">Verkeersbelasting 2024</span>
                        <span class="date">Gisteren</span>
                        <a href="inbox.html"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </section>
            <section class="payments">
                <div class="payments-container">
                    <div class="payment-title">
                        <h2>Aankomende Betalingen</h2>
                        <a href="inbox.html">Alles bekijken</a>
                    </div>
                    <div class="payments-row">
                        <span class="title">Verzekeringspremie</span>
                        <span class="bedrag">€40</span>
                        <span class="date">2 mei 2024</span>
                        <a class="hovering" href="inbox.php"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="payments-row">
                        <span class="title">Wegenbelasting</span>
                        <span class="bedrag">€80</span>
                        <span class="date">Gisteren</span>
                        <a id="hovering" href="inbox.php"><i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="payments-row">
                        <span class="title">APK Keuring</span>
                        <span class="bedrag">€40</span>
                        <span class="date">7 mei 2024</span>
                        <a class="hovering" href="#"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </section>
        </div>
        

        <div class="main-right">
            <section class="deadlines">
                <div class="deadlines-text">
                    <h2>Deadlines</h2>
                    <input type="date" id="deadline-date" name="deadline-date" value="2024-06-20">
                </div>
                <div class="deadlines-inhoud">
                    <p>U heeft geen deadlines tegen vandaag.</p>
                </div>
            </section>
        </div>
        </div>
    </div>
        <div class="no-vehicles" onclick="showOverlay()<?php echo $hasVehicles ? 'hidden' : ''; ?>">
            <p>Voertuig toevoegen</p>
        <button id="add-vehicle-btn"> <span class="plus" >+</span></button>
    </div>
        <div id="overlay2" class="overlay2"></div>
        <div id="popup" class="popup">
            <p>vehicle added!</p>
        </div>
    
        <div id="overlay" class="overlay">
            <div class="container2">
                <h2>Voertuig Toevoegen</h2>
                <form id="licensePlateForm" action="save_license_plate.php" method="POST">
                    <div class="input-group">
                        <img src="images/B.png" alt="EU flag">
                        <input type="text" name="licensePlate" id="licensePlate" placeholder="Kenteken" oninput="enableAddButton()" required>
                    </div>
                    <button type="submit" id="addButton" disabled>Voeg toe</button>
                </form>
            </div>
        </div>
        
        
                
            </div>
        </div>
        
    <script src="home.js"></script>
    <script src="calendar.js"></script>
</body>
</html>
