function scrollToCard(index) {
  const slides = document.querySelectorAll('.slider-content');
  const dots = document.querySelectorAll('.dot');

  slides.forEach((slide, slideIndex) => {
      if (slideIndex === index) {
          slide.classList.add('visible');
      } else {
          slide.classList.remove('visible');
      }
  });

  dots.forEach((dot, dotIndex) => {
      if (dotIndex === index) {
          dot.classList.add('active');
      } else {
          dot.classList.remove('active');
      }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  scrollToCard(0); // Initially display the first slide
});





  let detailsShown = false;

  function showOverlay() {
      document.getElementById('overlay').style.display = 'flex';
  }

  function hideOverlay() {
      document.getElementById('overlay').style.display = 'none';
  }

  function enableAddButton() {
      const licensePlateInput = document.getElementById('licensePlate').value;
      const addButton = document.getElementById('addButton');
      if (licensePlateInput.trim() !== "") {
          addButton.classList.remove('disabled');
      } else {
          addButton.classList.add('disabled');
      }
  }

  function handleAddButtonClick() {
      if (!detailsShown) {
          showDetails();
      } else {
          showPopup();
      }
  }

  function showDetails() {
      const addButton = document.getElementById('addButton');
      if (!addButton.classList.contains('disabled')) {
          document.getElementById('details').style.display = 'block';
          detailsShown = true;
      }
  }

  function showPopup() {
      document.getElementById('overlay2').style.display = 'flex';
      document.getElementById('popup').style.display = 'block';

      setTimeout(function() {
          window.location.href = 'home.php';  // Vervang door de gewenste URL
      }, 2000);
  }


  function enableAddButton() {
    var input = document.getElementById('licensePlate').value;
    console.log(input); // Check the input value in the browser console
    document.getElementById('addButton').disabled = input.length === 0;
}


