function scrollToCard(index) {
  const slides = document.querySelectorAll('.slider-content');
  const dots = document.querySelectorAll('.dot');

  slides.forEach((slide, slideIndex) => {
      if (slideIndex === index) {
          slide.classList.add('visible');
      } else {
          slide.classList.remove('visible');
      }
  });

  dots.forEach((dot, dotIndex) => {
      if (dotIndex === index) {
          dot.classList.add('active');
      } else {
          dot.classList.remove('active');
      }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  scrollToCard(0); // Initially display the first slide
});





  let detailsShown = false;
  document.addEventListener('DOMContentLoaded', function() {
    const overlay = document.getElementById('overlay');
    const container = document.querySelector('.container2');

    overlay.addEventListener('click', function(event) {
        // Controleer of de klik buiten de container2 plaatsvond
        if (!container.contains(event.target)) {
            overlay.style.display = 'none'; // Verberg de overlay
        }
    });
});

  function showOverlay() {
      document.getElementById('overlay').style.display = 'flex';
  }

  function hideOverlay() {
      document.getElementById('overlay').style.display = 'none';
  }

  function enableAddButton() {
      const licensePlateInput = document.getElementById('licensePlate').value;
      const addButton = document.getElementById('addButton');
      if (licensePlateInput.trim() !== "") {
          addButton.classList.remove('disabled');
      } else {
          addButton.classList.add('disabled');
      }
  }

  function handleAddButtonClick() {
      if (!detailsShown) {
          showDetails();
      } else {
          showPopup();
      }
  }

  function showDetails() {
      const addButton = document.getElementById('addButton');
      if (!addButton.classList.contains('disabled')) {
          document.getElementById('details').style.display = 'block';
          detailsShown = true;
      }
  }

  function showPopup() {
      document.getElementById('overlay2').style.display = 'flex';
      document.getElementById('popup').style.display = 'block';

      setTimeout(function() {
          window.location.href = 'home.php';  // Vervang door de gewenste URL
      }, 2000);
  }


  function enableAddButton() {
    var input = document.getElementById('licensePlate').value;
    console.log(input); // Check the input value in the browser console
    document.getElementById('addButton').disabled = input.length === 0;
}


document.addEventListener('DOMContentLoaded', function() {
    const carSelect = document.getElementById('cars');
    
    // Selecteer alleen de eerste twee '.payments-row' elementen
    const paymentRows = document.querySelectorAll('.payments-row .bedrag');
    const randomizableRows = Array.from(paymentRows).slice(0, 2); // Eerste twee rijen

    function generateRandomAmounts() {
        randomizableRows.forEach(function(row) {
            const randomAmount = Math.floor(Math.random() * 100) + 50; // Getal tussen 50 en 500
            row.textContent = `€${randomAmount}`;
        });
    }

    // Voeg event listener toe aan de dropdown
    carSelect.addEventListener('change', function() {
        generateRandomAmounts();
    });

    // Genereer eenmalig getallen bij laden van de pagina
    generateRandomAmounts();
});


document.addEventListener('DOMContentLoaded', function() {
    const carSelect = document.getElementById('cars');

    function updateDeadlines() {
        const selectedPlate = carSelect.value;
        const deadlinesContainer = document.querySelector('.deadlines-inhoud');
        deadlinesContainer.innerHTML = ''; // Verwijder bestaande deadlines

        // Deadlines voor nummerplaten op basis van het eerste cijfer
        const deadlinesData = {
            '1': [
                {
                    title: 'Keuring',
                    text: 'Je kan al naar de keuring vanaf 30 juni',
                    date: '30 Aug 2024'
                },
                {
                    title: 'Jaarlijks onderhoud',
                    text: 'Breng de auto binnen voor het jaarlijkse onderhoud.',
                    date: '1 Sep 2024'
                },
                
            ],
            '2': [
               
    
                {
                    title: 'Jaarlijks onderhoud',
                    text: 'Breng de auto binnen voor het jaarlijkse onderhoud.',
                    date: '5 Sep 2024'
                }
            ],
            'other': [
                {
                    title: 'Keuring',
                    text: 'Je kan al naar de keuring vanaf 1 augustus',
                    date: '1 Oct 2024'
                },
                {
                    title: 'Jaarlijks onderhoud',
                    text: 'Breng de auto binnen voor het jaarlijkse onderhoud.',
                    date: '10 Sep 2024'
                },
               
            ]
        };

        // Controleer het eerste karakter van de nummerplaat
        let deadlines;
        if (selectedPlate.startsWith('1')) {
            deadlines = deadlinesData['1'];
        } else if (selectedPlate.startsWith('2')) {
            deadlines = deadlinesData['2'];
        } else {
            deadlines = deadlinesData['other'];
        }

        // Voeg de deadlines toe aan de HTML-structuur
        deadlines.forEach(deadline => {
            const deadlineItem = document.createElement('div');
            deadlineItem.className = 'deadline-item';

            const deadlineTitle = document.createElement('div');
            deadlineTitle.className = 'deadline-title';
            deadlineTitle.textContent = deadline.title;

            const deadlineContent = document.createElement('div');
            deadlineContent.className = 'deadline-content';

            const deadlineLine = document.createElement('div');
            deadlineLine.className = 'deadline-line';

            const deadlineText = document.createElement('div');
            deadlineText.className = 'deadline-text';
            deadlineText.textContent = deadline.text;

            const deadlineDate = document.createElement('div');
            deadlineDate.className = 'deadline-date';
            deadlineDate.textContent = deadline.date;

            deadlineContent.appendChild(deadlineLine);
            deadlineContent.appendChild(deadlineText);
            deadlineContent.appendChild(deadlineDate);

            deadlineItem.appendChild(deadlineTitle);
            deadlineItem.appendChild(deadlineContent);

            deadlinesContainer.appendChild(deadlineItem);

            // Voeg een scheidingslijn toe
            const separator = document.createElement('div');
            separator.className = 'deadline-separator';
            deadlinesContainer.appendChild(separator);
        });
    }

    // Voeg event listener toe aan de dropdown
    carSelect.addEventListener('change', updateDeadlines);

    // Roep de functie eenmalig aan bij pagina laden
    updateDeadlines();
});

