<?php
session_start();
require 'config.php'; // Include the database configuration

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $licensePlate = $_POST['licensePlate'];
    $userId = $_SESSION['user_id'];

    try {
        // Prepare the SQL statement
        $stmt = $pdo->prepare("INSERT INTO vehicles (user_id, license_plate) VALUES (:user_id, :license_plate)");

        // Bind parameters to the statement
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':license_plate', $licensePlate);

        // Execute the statement
        if ($stmt->execute()) {
            header("Location: home.php");
        } else {
            echo "Fout bij het toevoegen van het voertuig.";
        }
    } catch (PDOException $e) {
        echo "Fout bij het toevoegen van het voertuig: " . $e->getMessage();
    }
}
?>
