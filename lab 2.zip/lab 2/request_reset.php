<?php
// request_reset.php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    $sql = "SELECT id FROM users WHERE email = :email";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $reset_token = bin2hex(random_bytes(16));
        $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $sql = "INSERT INTO password_resets (user_id, reset_token, expires_at) VALUES (:user_id, :reset_token, :expires_at)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['user_id' => $user['id'], 'reset_token' => $reset_token, 'expires_at' => $expires_at]);

        // Send the reset token to the user's email address (implement the actual email sending)
        // For demonstration, we'll just echo the token URL
        echo "Password reset email sent! <a href='reset_password_form.php?token=$reset_token'>Click here to reset your password</a>";
    } else {
        echo "No user found with that email address.";
    }
}
?>
