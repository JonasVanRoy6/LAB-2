document.addEventListener('DOMContentLoaded', () => {
    // Mobile navigation menu functionality
    const menuButton = document.getElementById('menu-button');
    const mobileNav = document.getElementById('mobile-nav');
    const closeNavButton = document.getElementById('close-nav');

    // Toggle the mobile navigation menu
    menuButton.addEventListener('click', () => {
        mobileNav.classList.toggle('active');
    });

    // Close the mobile navigation menu when clicking outside of it
    document.addEventListener('click', (event) => {
        if (!mobileNav.contains(event.target) && !menuButton.contains(event.target)) {
            mobileNav.classList.remove('active');
        }
    });

    // Close the mobile navigation menu when the close button is clicked
    if (closeNavButton) {
        closeNavButton.addEventListener('click', () => {
            mobileNav.classList.remove('active');
        });
    }
});