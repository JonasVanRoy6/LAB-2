<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $sql = "SELECT firstname, lastname, email FROM users WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo "User not found.";
        exit;
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instellingen</title>
    <link rel="stylesheet" href="instellingen.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="container">
        <section class="sidebar">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
            </div>
            <ul class="nav">
                <li class="nav-item">
                    <i class='bx bxs-home' ></i>
                    <a href="home.php"><span>Home</span></a>
                </li>
                <li class="nav-item">
                    <i class='bx bxs-inbox'></i>
                    <a href="inbox.php"><span>Inbox</span></a>
                </li>
               
                <li class="nav-item">
                    <i class='bx bxs-calendar'></i>
                    <a href="kalender.php"><span>Kalender</span></a>
                </li>
            </ul>
            <div class="separator"></div>
            <ul class="nav general">
                <span id="algemeen">Algemeen</span>
                <li class="nav-item active">
                    <i class='bx bx-cog' ></i>
                    <a href="instellingen.php"><span>Instellingen</span></a>
                </li>
                <li class="nav-item">
                    <i class='bx bxs-help-circle' ></i>
                    <a href="help.html"><span>Help</span></a>
                </li>
                <div class="nav-item logout">
                    <i class='bx bx-log-out' ></i>
                    <a href="login.html"><span>Logout</span></a>
                </div>
            </ul>
        </section>
        <main>
            <header>
                <h1>Instellingen</h1>
                
            </header>
            <section class="settings">
                <div class="sidebar-settings">
                    <ul>
                        <a href="instellingen.php">
                        <li class="active">Mijn Profiel</li></a>
                        <a href="betaalmethodes.html">
                        <li >Betaalmethodes</li></a>
                        <a href="meldingen.html">
                        <li >Meldingen</li></a>
                        <a href="weergave.html">
                        <li>Weergave</li></a>
                        <a href="documenten.html">
                        <li>Documenten</li></a>
                        <a href="Transactiegeschiedenis.html">
                        <li>Transactiegeschiedenis</li></a>
                        <a href="acountverwijderen.html">
                        <li>Account Verwijderen</li></a>
                    </ul>
                </div>
                <hr class="vertical">
                <div class="content">
                    
                        <div class="profile-info">
                            <h3  class="h3">Mijn Profiel</h3>
                            <div class="info-container">
                                <div class="info-grid">
                                    <div class="info-item">
                                        <strong>Voornaam</strong>
                                        <span><?php echo htmlspecialchars($user['firstname']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <strong>Achternaam</strong>
                                        <span><?php echo htmlspecialchars($user['lastname']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <strong>E-mailadres</strong>
                                        <span><?php echo htmlspecialchars($user['email']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <strong>Telefoon</strong>
                                        <span>+32 123 456 789</span>
                                    </div>
                                </div>
                                <button class="edit-button" id="openInfoOverlay">Bewerken</button>
                            </div>
                        </div>
                        <div class="profile-info">
                            <h3>Adres</h3>
                            <div class="info-container">
                            <div class="info-grid">
                                <div class="info-item">
                                    <strong>Straat</strong>
                                    <span>Voorbeeldlaan</span>
                                </div>
                                <div class="info-item">
                                    <strong>Huisnummer</strong>
                                    <span>123</span>
                                </div>
                                <div class="info-item">
                                    <strong>Gemeente</strong>
                                    <span>Voorbeeld</span>
                                </div>
                                <div class="info-item">
                                    <strong>Postcode</strong>
                                    <span>1234</span>
                                </div>
                            </div>
                            <button class="edit-button" id="openAddressOverlay">Bewerken</button>
                        </div>
                    </div>
                    </div>
                </div>
                <div id="overlay" class="overlay">
                    <div class="overlay-content">
                        <h2>Profielfoto wijzigen</h2>
                        <img src="images/persoon.png" alt="Profile Icon" class="profile-icon">
                        <div class="upload-section">
                            <input type="file" id="fileUpload" class="file-upload">
                            <label for="fileUpload" class="upload-label"> <img src="images/upload.png" alt="">Foto uploaden</label>
                        </div>
                        <div class="buttons">
                            <button id="cancelButton" class="button">Annuleren</button>
                            <button id="saveButton" class="button save-button">Opslaan</button>
                        </div>
                    </div>
                </div>
            
                <div id="infoOverlay" class="overlay">
                    <div class="overlay-content">
                        <h2>Persoonlijke Informatie</h2>
                        <form id="infoForm">
                            <div class="form-group">
                                <label for="firstName">Voornaam</label>
                                <input type="text" id="firstName" name="firstName" value="Jelle">
                            </div>
                            <div class="form-group">
                                <label for="lastName">Achternaam</label>
                                <input type="text" id="lastName" name="lastName" value="De Boeck">
                            </div>
                            <div class="form-group">
                                <label for="email">E-mailadres</label>
                                <input type="email" id="email" name="email" value="dbjelle@gmail.com">
                            </div>
                            <div class="form-group">
                                <label for="phone">Telefoon</label>
                                <div class="phone-input">
                                    <img src="images/vlag.png" alt="BE Flag">
                                    <input type="text" id="phone" name="phone" value="123 456 789">
                                </div>
                            </div>
                            <div class="buttons">
                                <button type="button" id="cancelInfoButton" class="button">Annuleren</button>
                                <button type="submit" id="saveInfoButton" class="button save-button">Opslaan</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div id="addressOverlay" class="overlay">
                    <div class="overlay-content">
                        <h2>Adres</h2>
                        <form id="addressForm">
                            <div class="form-group">
                                <label for="street">Straat</label>
                                <input type="text" id="street" name="street" value="Voorbeeldlaan">
                            </div>
                            <div class="form-group">
                                <label for="houseNumber">Huisnummer</label>
                                <input type="text" id="houseNumber" name="houseNumber" value="123">
                            </div>
                            <div class="form-group">
                                <label for="city">Gemeente</label>
                                <input type="text" id="city" name="city" value="Voorbeeld">
                            </div>
                            <div class="form-group">
                                <label for="email">E-mailadres</label>
                                <input type="email" id="addressEmail" name="email" value="dbjelle@gmail.com">
                            </div>
                            <div class="buttons">
                                <button type="button" id="cancelAddressButton" class="button">Annuleren</button>
                                <button type="submit" id="saveAddressButton" class="button save-button">Opslaan</button>
                            </div>
                        </form>
                    </div>
                </div>
                <script src="profiel.js"></script>
            </section>
        </main>
    </div>
</body>
</html>
