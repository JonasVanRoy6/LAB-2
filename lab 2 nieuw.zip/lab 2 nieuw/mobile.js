document.addEventListener('DOMContentLoaded', () => {
    // Mobile navigation menu functionality
    const menuButton = document.getElementById('menu-button');
    const mobileNav = document.getElementById('mobile-nav');
    const closeNavButton = document.getElementById('close-nav');

    // Toggle the mobile navigation menu
    menuButton.addEventListener('click', () => {
        mobileNav.classList.toggle('active');
    });

    // Close the mobile navigation menu when clicking outside of it
    document.addEventListener('click', (event) => {
        if (!mobileNav.contains(event.target) && !menuButton.contains(event.target)) {
            mobileNav.classList.remove('active');
        }
    });

    // Close the mobile navigation menu when the close button is clicked
    if (closeNavButton) {
        closeNavButton.addEventListener('click', () => {
            mobileNav.classList.remove('active');
        });
    }

    // Section navigation functionality
    const links = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.content-section');
    const sectionTitle = document.getElementById('section-title');

    // Function to update active link and section
    function updateActiveLinkAndSection(targetId, title) {
        // Remove the 'active' class from all links
        links.forEach(link => link.classList.remove('active'));

        // Add the 'active' class to the clicked link
        const activeLink = document.querySelector(`.nav-link[data-target="${targetId}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        // Hide all sections
        sections.forEach(section => section.style.display = 'none');

        // Show the target section
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
            targetSection.style.display = 'block';
        }

        // Update the section title
        sectionTitle.textContent = title;
    }

    // Set the default section and title on page load
    updateActiveLinkAndSection('messages', 'Recente Berichten');

    // Add event listeners to all links
    links.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const targetId = link.getAttribute('data-target');
            switch (targetId) {
                case 'messages':
                    updateActiveLinkAndSection(targetId, 'Recente Berichten');
                    break;
                case 'deadlines':
                    updateActiveLinkAndSection(targetId, 'Aankomende Deadlines');
                    break;
                case 'payments':
                    updateActiveLinkAndSection(targetId, 'Aankomende Betalingen');
                    break;
                default:
                    updateActiveLinkAndSection(targetId, '');
            }
        });
    });
});