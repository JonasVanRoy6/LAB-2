document.addEventListener('DOMContentLoaded', () => {
    // Mobile navigation menu functionality
    const menuButton = document.getElementById('menu-button');
    const mobileNav = document.getElementById('mobile-nav');
    const closeNavButton = document.getElementById('close-nav');

    // Toggle the mobile navigation menu
    menuButton.addEventListener('click', () => {
        mobileNav.classList.toggle('active');
    });

    // Close the mobile navigation menu when clicking outside of it
    document.addEventListener('click', (event) => {
        if (!mobileNav.contains(event.target) && !menuButton.contains(event.target)) {
            mobileNav.classList.remove('active');
        }
    });

    // Close the mobile navigation menu when the close button is clicked
    if (closeNavButton) {
        closeNavButton.addEventListener('click', () => {
            mobileNav.classList.remove('active');
        });
    }

    // Week navigation functionality for the calendar
    let currentWeekStart = new Date(); // Get today's date
    currentWeekStart.setDate(currentWeekStart.getDate() - currentWeekStart.getDay() + 1); // Set to Monday of the current week

    const weekEvents = {
        '2024-09-05': { "Donderdag": ["Keuring om 11:00"] },
        '2024-09-16': { "Maandag": ["Verzekeringspremie betalen"] },
        '2024-10-10': { "Donderdag": ["Keuring om 09:00"] }
    };

    const updateCalendar = (startDate) => {
        const dayRows = document.querySelectorAll('.day-row');
        const daysOfWeek = ['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag'];

        dayRows.forEach((row, index) => {
            const dayDate = new Date(startDate);
            dayDate.setDate(dayDate.getDate() + index);
            const formattedDate = dayDate.toISOString().split('T')[0]; // Format as YYYY-MM-DD

            // Update the day and week day
            const dayDateDiv = row.querySelector('.day-date');
            const dayNameDiv = row.querySelector('.day-name');
            const eventDiv = row.querySelector('.events');
            
            // Set the day and week day
            dayDateDiv.textContent = dayDate.getDate();
            dayNameDiv.textContent = daysOfWeek[index];
            
            // Clear previous events
            eventDiv.innerHTML = '';
            
            // Ensure the events object exists for the current date
            if (weekEvents[formattedDate] && weekEvents[formattedDate][daysOfWeek[index]]) {
                const events = weekEvents[formattedDate][daysOfWeek[index]];
                events.forEach(event => {
                    const eventSpan = document.createElement('span');
                    eventSpan.className = 'event';
                    eventSpan.textContent = event;
                    eventDiv.appendChild(eventSpan);
                });
            }
        });

        document.getElementById('current-week').innerText = `${formatDate(startDate)} - ${formatDate(new Date(startDate.getTime() + 6 * 24 * 60 * 60 * 1000))}`;
    };

    const formatDate = (date) => {
        const options = { day: '2-digit', month: 'short' };
        return date.toLocaleDateString('nl-NL', options).replace(/\s/, ' '); // Replace space with hyphen
    };

    document.getElementById('prev-week').addEventListener('click', () => {
        currentWeekStart.setDate(currentWeekStart.getDate() - 7);
        updateCalendar(currentWeekStart);
    });

    document.getElementById('next-week').addEventListener('click', () => {
        currentWeekStart.setDate(currentWeekStart.getDate() + 7);
        updateCalendar(currentWeekStart);
    });

    // Initialize the calendar on page load
    updateCalendar(currentWeekStart);
});
