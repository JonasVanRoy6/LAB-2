<?php
session_start();
require 'config.php'; // Include the PDO connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}

try {
    // Retrieve the logged-in user's ID from the session
    $userId = $_SESSION['user_id'];

    $stmt = $pdo->prepare("SELECT firstname FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $firstName = $user['firstname'];

    // Prepare the SQL statement to fetch all license plates
    $stmt = $pdo->prepare("SELECT license_plate FROM vehicles WHERE user_id = :user_id ORDER BY created_at DESC");
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();
    $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $hasVehicles = !empty($vehicles);

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>


<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalender</title>
    <link rel="stylesheet" href="kalender.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="desktop">
    <div class="container">
        <section class="sidebar">
            <div class="logo">
                <img src="images/logo.png" alt="logo">
            </div>
            <ul class="nav">
                <li class="nav-item">
                    <i class='bx bxs-home' ></i>
                    <a href="home.php"><span>Home</span></a>
                </li>
                <li class="nav-item">
                    <i class='bx bxs-inbox'></i>
                    <a href="inbox.php"><span>Inbox</span></a>
                </li>
                
                <li class="nav-item active">
                    <i class='bx bxs-calendar'></i>
                    <a href="kalender.php"><span>Kalender</span></a>
                </li>
            </ul>
            <div class="separator"></div>
            <ul class="nav general">
                <span id="algemeen">Algemeen</span>
                <li class="nav-item">
                    <i class='bx bx-cog' ></i>
                    <a href="instellingen.php"><span>Instellingen</span></a>
                </li>
                <li class="nav-item">
                    <i class='bx bxs-help-circle' ></i>
                    <a href="help.html"><span>Help</span></a>
                </li>
                <div class="nav-item logout">
                    <i class='bx bx-log-out' ></i>
                    <a href="login.html"><span>Logout</span></a>
                </div>
            </ul>
        </section>
        <main class="main-content">
            <header>
                <h1>Kalender</h1>
                
            </header>

            <section class="kalender">
                <div class="kalender-container">
                    <div class="kalender-heading">
                        <h2>Mei 2024</h2>
                        <div class="navigation">
                            <label for="cars" class="car-label">Kies een kenteken:</label>
<select id="cars" name="cars">
    <?php foreach ($vehicles as $vehicle): ?>
        <option value="<?php echo htmlspecialchars($vehicle['license_plate']); ?>">
            <?php echo htmlspecialchars($vehicle['license_plate']); ?>
        </option>
    <?php endforeach; ?>
</select>

                            <a class="first"><i class='bx bx-left-arrow-alt'></i></a>
                            <a><i class='bx bx-right-arrow-alt'></i></a>
                        </div>
                    </div>
                    <table class="kalender-table">
                        <thead>
                            <tr>
                                <th>Ma</th>
                                <th>Di</th>
                                <th>Wo</th>
                                <th>Do</th>
                                <th>Vr</th>
                                <th>Za</th>
                                <th>Zo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="prev-month">27</td>
                                <td class="prev-month">28</td>
                                <td class="prev-month">29</td>
                                <td class="prev-month">30</td>
                                <td class="prev-month">31</td>
                                <td>1<div class="event">
                                    <i class='bx bx-euro'></i>
                                    <div class="event-title">
                                        <p>Verzekeringspremie</p>
                                        <p>betalen</p>
                                    </div>
                                </div></td>
                                <td>2</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>4</td>
                                <td>5</td>
                                <td>6</td>
                                <td>7</td>
                                <td>8</td>
                                <td>9</td>
                            </tr>
                            <tr>
                                <td>10</td>
                                <td>11</td>
                                <td>12</td>
                                <td>13</td>
                                <td>14<div class="event2">
                                    <i class='bx bx-time-five' ></i>
                                    <div class="event-title">
                                        <p>Onderhoud</p>
                                        <p>11:00</p>
                                    </div>
                                <td>15</td>
                                <td>16</td>
                            </tr>
                            <tr>
                                <td>17</td>
                                <td>18</td>
                                <td>19</td>
                                <td>20</td>
                                <td>21</td>
                                <td>22</td>
                                <td>23</td>
                            </tr>
                            <tr>
                                <td>24</td>
                                <td>25</td>
                                <td>26<div class="event3">
                                    <i class='bx bx-time-five' ></i>
                                    <div class="event-title">
                                        <p>Keuring</p>
                                        <p>9:00</p>
                                    </div>
                                <td>27</td>
                                <td>28</td>
                                <td>29</td>
                                <td>30</td>
                            </tr>
                            <tr>
                                <td class="prev-month">1</td>
                                <td class="prev-month">2</td>
                                <td class="prev-month">3</td>
                                <td class="prev-month">4</td>
                                <td class="prev-month">5</td>
                                <td class="prev-month">6</td>
                                <td class="prev-month">7</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</div>

<div class="mobile">
    <section class="heading">
        <div class="header">
            <a href="#" id="menu-button"><i class='bx bx-menu-alt-left'></i></a>
            <div class="car-picker">
                <a href=""><i class='bx bx-plus'></i></a>
                <label for="cars" class="car-label"></label>
                <select class="cars">
                    <option value="volvo">1 - ABC - 123</option>
                    <option value="saab">2 - DEF - 456</option>
                    <option value="vw">3 - GHI - 789</option>
                </select>
            </div>
            <i class='bx bx-dots-vertical-rounded'></i>
        </div>

        <div class="mobile-nav" id="mobile-nav">
            <button id="close-nav" class="close-nav">&times;</button>
            <a href="home.php" class="nav-item">Home</a>
            <a href="instellingen.html" class="nav-item">Instellingen</a>
            <a href="#" class="nav-item">Logout</a>
        </div>
    
        <div class="week-navigation">
            <button id="prev-week" class="week-nav-button"><i class='bx bx-chevron-left'></i></button>
            <span id="current-week">Week 1</span>
            <button id="next-week" class="week-nav-button"><i class='bx bx-chevron-right' ></i></button>
        </div>
    </section>
    
    <div class="content">
        <div class="week-calendar" id="week-calendar">
            <div class="day-row">
                <div class="day-column">
                    <div class="day-date"></div>
                    <div class="day-name">Maandag</div>
                </div>
                <div class="events"></div>
            </div>
            <div class="day-row">
                <div class="day-column">
                    <div class="day-date"></div>
                    <div class="day-name">Dinsdag</div>
                </div>
                <div class="events"></div>
            </div>
            <div class="day-row">
                <div class="day-column">
                    <div class="day-date"></div>
                    <div class="day-name">Woensdag</div>
                </div>
                <div class="events"></div>
            </div>
            <div class="day-row">
                <div class="day-column">
                    <div class="day-date"></div>
                    <div class="day-name">Donderdag</div>
                </div>
                <div class="events"></div>
            </div>
            <div class="day-row">
                <div class="day-column">
                    <div class="day-date"></div>
                    <div class="day-name">Vrijdag</div>
                </div>
                <div class="events"></div>
            </div>
            <div class="day-row">
                <div class="day-column">
                    <div class="day-date"></div>
                    <div class="day-name">Zaterdag</div>
                </div>
                <div class="events"></div>
            </div>
            <div class="day-row">
                <div class="day-column">
                    <div class="day-date"></div>
                    <div class="day-name">Zondag</div>
                </div>
                <div class="events"></div>
            </div>
        </div>
    </div>
</div>
    <script src="kalender-mobile.js"></script>
    <script src="kalender.js"></script>
</body>
</html>
